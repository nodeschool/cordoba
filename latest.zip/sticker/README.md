Sticker BA
=========

![sticker](nodeschoolba-official.jpg)

Agradecimientos
----

Gracias al team de [Aerolab](https://aerolab.co/) por el diseño!

**Free Software, Hell Yeah!**
